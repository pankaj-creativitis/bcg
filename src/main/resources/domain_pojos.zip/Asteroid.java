package com.mean.business.domain;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@javax.persistence.Entity
@Table(name = "ASTEROID")
public class Asteroid {
	
	private String asteroidId;
	private String asteroidName;
	private String asteroidNearBodyName;
	
    @Id
    @Column(name = "ASTEROIDID", nullable = false, unique = true)
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
	public String getAsteroidId() {
		return asteroidId;
	}
	public void setAsteroidId(String asteroidId) {
		this.asteroidId = asteroidId;
	}
	
	@Column(name = "ASTEROIDNAME")
	public String getAsteroidName() {
		return asteroidName;
	}
	public void setAsteroidName(String asteroidName) {
		this.asteroidName = asteroidName;
	}
	
	@Column(name = "ASTEROIDNEARBODYNAME")
	public String getAsteroidNearBodyName() {
		return asteroidNearBodyName;
	}
	public void setAsteroidNearBodyName(String asteroidNearBodyName) {
		this.asteroidNearBodyName = asteroidNearBodyName;
	}

	
}
